import pyglet
import time
import random

def wordLoad():
    words = []

    with open("data/word.txt", "r") as file:
        for line in file:
            # 오른쪽 뉴라인 캐릭터를 제거하고 리스트에 추가
            word = line.strip("\n")
            words.append(word)

    # print(words)

    return words

def gameRun(words):
    startTime = time.time()
    endTime = 0
    elapsed_time = 0

    count = 0
    wrong_count = 0

    while count < 5:
        count += 1
        ques = random.choice(words)
        ans = input(f"Question #{count}: {ques} :")
        if ans == ques:
            print("맞았습니다!")
            sound = pyglet.resource.media('assets/good.wav', streaming = True)
            sound.play()
            time.sleep(1)
        else:
            print("틀렸습니다.")
            wrong_count += 1
            sound = pyglet.resource.media('assets/bad.wav', streaming=True)
            sound.play()
            time.sleep(1)

        print()
        
    if wrong_count == 0:
        print("합격했습니다.")
    else:
        print("불합격했습니다.")

    

    endTime = time.time()
    elapsed_time = endTime - startTime

    print(f"게임 걸린 시간 : {elapsed_time:.2f}초 맞춘 개수: {count - wrong_count}개 틀린 개수: {wrong_count}개")

    sound = pyglet.resource.media('assets/good.wav', streaming = True)
    sound.play()
    time.sleep(1)

words = wordLoad()
gameRun(words)
