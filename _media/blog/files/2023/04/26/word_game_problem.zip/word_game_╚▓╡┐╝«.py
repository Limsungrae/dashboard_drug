# 단어 데이터가 저장되어 있는 파일을 로딩하여 단어들을 리스트 객체 변수로 저장하시오

## 워드 게임을 만들기 위해 data 폴더에 word.txt 파일이 제공되었음
## python 코드로 word.txt 파일을 로딩하여 각 word를 요소로 가지는 리스트 객체변수 만들기
## 각 word를 리스트에 추가하기전에 공백과 오른쪽 뉴라인캐릭터를 제거하고 추가하기

import pyglet
import time
import random

words = []

with open("data/word.txt", "r") as file:
    for line in file:
        # 오른쪽 뉴라인 캐릭터를 제거하고 리스트에 추가
        word = line.strip("\n")
        words.append(word)

print(words)

startTime = time.time()

correct_count = 0
ques_num = 0

while ques_num < 5: # 5번 문제를 출력
    ques_num = ques_num + 1
    ques = random.choice(words)
    ans = input(f"Question #{ques_num}: {ques} :")
    if ans == ques:
        print("마 춰 숴~")
        correct_count = correct_count+ 1
        sound = pyglet.resource.media('assets/good.wav', streaming=True)
        sound.play()
        time.sleep(1)
    else:
        print("틀 려 숴~")
        sound = pyglet.resource.media('assets/bad.wav', streaming=True)
        sound.play()
        time.sleep(1)
    
    print()

if correct_count >= 3:
    print("합격했습니다!")

else:
    print("불합격했습니다!")

endTime = time.time()
elapsed_time = endTime - startTime

print(f"게임 걸린 시간: {elapsed_time:.2f}초, 맞춘 개수: {correct_count}개")
# print(f"맞춘 개수: {count}")


# 필요한 내장, 외장 모듈을 작성 파일로 import 하시오

## 코드를 작성하기 위해 필요한 내장 모듈로 import 하기
## 미디어 파일을 사용하기 위해 pyglet 모듈이 필요하므로 모듈을 설치하고 import 하기


# print("굿~~")


# print("배드~")



